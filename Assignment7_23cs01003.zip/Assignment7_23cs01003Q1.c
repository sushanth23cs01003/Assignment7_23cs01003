#include <stdio.h>

int main() {
    char s[100];
    char a;
    int count = 0;


    printf("Enter a word: ");
    scanf("%s", s);


    printf("Enter a letter: ");
    scanf(" %c", &a);
    for (int i = 0; s[i] != '\0'; i++) {
        if (s[i] == a) {
            count++;
        }
    }


    printf("Frequency is  %d",count);

    return 0;
}
