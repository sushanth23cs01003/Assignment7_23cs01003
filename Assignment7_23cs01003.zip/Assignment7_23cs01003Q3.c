#include <stdio.h>
void reverse() {
    char word;
    scanf("%c", &word);
    if (word != '\n') {
        reverse();
    }
    printf("%c", word);
}
int main() {
    printf("Enter a word: ");
    reverse();
    return 0;
}