#include <stdio.h>
#include <string.h>
int main(){
    char a[100];
    printf("Enter the word:");
    gets(a);
    int x=strlen(a);
    int b=0;
    for(int i=0;i<x/2;i++)
    if(a[i]==a[x-i-1]){
        b++;
    }
    if(b==x/2){
        printf("It is a palindrome");
    }
    else{
        printf("It is not a palindrome ");
    }
}